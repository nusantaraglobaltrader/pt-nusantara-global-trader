PT LAKSANA THREE KARYA – WEBSITE PHOTO GALLERY

1. Upload all six JPEG files in this folder to the root of your GitHub repository:
   nusantaraglobaltrader/pt-nusantara-global-trader
   (same level as index.html).
2. Open index.html and edit it.
3. Find the existing Business Activities section/card.
4. Replace that old section with the HTML in SUPPLIER-GALLERY-HTML.txt.
5. Commit changes. Refresh the published website after GitHub Pages updates.

The HTML uses the exact filenames included in this ZIP.
The captions describe only what is visible in the supplied photos. Confirm
with PT Laksana Three Karya before making claims about production capacity,
certifications, export history, or formal partnership status.
